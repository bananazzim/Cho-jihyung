temp_C=30
temp_F=(temp_C*9/5)+32
print("{}C => {}F".format(temp_C,temp_F))