weight=98
height=1.79
BMI=weight/(height*height)
print("내 bmi는 {} kg/m^2 이다.".format(BMI))